<nav class="navbar navbar-default" role="navigation">

<div class="navbar-header">
  <a class="navbar-brand" href="/"><img height="25" src="img/AWS_logo_RGB.png" /></a>
</div>

<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
  <ul class="nav navbar-nav">
    <li>
      <a href="load.php">Load Test</a>
    </li>
    <li>
      <a href="rds.php">RDS</a>
    </li>
  </ul>
</div>

</nav>
